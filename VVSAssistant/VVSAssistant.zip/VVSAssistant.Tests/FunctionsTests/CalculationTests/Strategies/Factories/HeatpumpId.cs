﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    public enum HeatpumpId
    { Compress7000=1, Vitocal200S, Compress5000, Vitocal350A, Compress6000AW5 }
}
﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    public enum BoilerId
    { Cerapur = 1, Condens5000, LoganoSB150, EuroPurACUWater, Condens9000Water
      , EuroPurUnitSolarWater, Vitodens200, Vitoladens300W}
}
﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    public enum TempControlId
    { FB100 = 1, CW400, Vitotronic200}
}
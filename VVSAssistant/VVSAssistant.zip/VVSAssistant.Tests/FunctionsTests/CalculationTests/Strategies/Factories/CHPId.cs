﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    public enum CHPId
    {
        Vitobloc200 = 1,
    }
}

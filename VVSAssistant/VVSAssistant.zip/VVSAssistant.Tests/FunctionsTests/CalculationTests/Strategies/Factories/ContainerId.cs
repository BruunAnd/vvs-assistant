﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    public enum ContainerId
    { ClassBHighVolume = 1, BST500, SM500, Vitocell140E400l, Vitocell140E950l, Vitocell300B, BST50080, SW750, CERA110L, BST5006 }
}
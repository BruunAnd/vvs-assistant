﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    public enum SolarPanelId
    { LogasolSKN = 1, LogasolSKNWater, FKC25Water, Vitosol300T, LogasolSKN40, Vitosol200T, Vitosol200TSP2A }
}
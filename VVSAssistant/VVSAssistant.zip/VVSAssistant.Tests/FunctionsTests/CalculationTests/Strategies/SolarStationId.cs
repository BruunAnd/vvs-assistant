﻿namespace VVSAssistant.Tests.FunctionsTests.CalculationTests.Strategies
{
    enum SolarStationId
    { SBT1003 = 1, SBT653, SBT353, SBT1603 }
}
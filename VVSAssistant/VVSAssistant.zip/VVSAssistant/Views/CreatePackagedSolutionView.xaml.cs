﻿using System.Windows.Controls;
using System.Windows.Media;
using VVSAssistant.ViewModels;

namespace VVSAssistant.Views
{
    /// <summary>
    /// Interaction logic for NewPackageSolutionView.xaml
    /// </summary>
    public partial class CreatePackagedSolutionView
    {
        public CreatePackagedSolutionView()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Documents;

namespace VVSAssistant.Views
{
    /// <summary>
    /// Interaction logic for PdfOfferLayout.xaml
    /// </summary>
    public partial class OfferLayout : FlowDocument
    {
        public OfferLayout()
        {
            InitializeComponent();
        }
    }
}

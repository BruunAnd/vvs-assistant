namespace VVSAssistant.Models
{
    public enum ApplianceTypes
    {
        HeatPump = 1,
        Boiler = 2,
        TemperatureController = 3,
        SolarPanel = 4,
        Container = 5,
        LowTempHeatPump = 6,
        CHP = 7,
        SolarStation = 8,
        WaterHeater
    }
}

﻿namespace VVSAssistant.Models.Interfaces
{
    internal interface ICopyable
    {
        object MakeCopy();
    }
}

﻿namespace VVSAssistant.Models.Interfaces
{
    public interface ICalculable
    {
        ApplianceTypes Type { get; set; }
        DataSheet DataSheet { get; set; }
    }
}

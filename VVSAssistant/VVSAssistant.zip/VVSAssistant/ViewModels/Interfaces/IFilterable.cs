﻿
namespace VVSAssistant.ViewModels.Interfaces
{
    public interface IFilterable
    {
        bool DoesFilterMatch(string query);
    }
}
